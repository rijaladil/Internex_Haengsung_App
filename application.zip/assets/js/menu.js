	function myFunction1() {
	  document.getElementById("myDropdown1").style.display="block";
	  document.getElementById("myDropdown2").style.display="none";
	  document.getElementById("myDropdown3").style.display="none";
	  document.getElementById("myDropdown4").style.display="none";
	  document.getElementById("myDropdown5").style.display="none";
	  document.getElementById("myDropdown6").style.display="none";
	  document.getElementById("myDropdown7").style.display="none";
	}
	function myFunction2() {
	  document.getElementById("myDropdown2").style.display="block";
	  document.getElementById("myDropdown1").style.display="none";
	  document.getElementById("myDropdown3").style.display="none";
	  document.getElementById("myDropdown4").style.display="none";
	  document.getElementById("myDropdown5").style.display="none";
	  document.getElementById("myDropdown6").style.display="none";
	  document.getElementById("myDropdown7").style.display="none";
	}
	function myFunction3() {
	  document.getElementById("myDropdown3").style.display="block";
	  document.getElementById("myDropdown1").style.display="none";
	  document.getElementById("myDropdown2").style.display="none";
	  document.getElementById("myDropdown4").style.display="none";
	  document.getElementById("myDropdown5").style.display="none";
	  document.getElementById("myDropdown6").style.display="none";
	  document.getElementById("myDropdown7").style.display="none";
	}
	function myFunction4() {
	  document.getElementById("myDropdown4").style.display="block";
	  document.getElementById("myDropdown1").style.display="none";
	  document.getElementById("myDropdown2").style.display="none";
	  document.getElementById("myDropdown3").style.display="none";
	  document.getElementById("myDropdown5").style.display="none";
	  document.getElementById("myDropdown6").style.display="none";
	  document.getElementById("myDropdown7").style.display="none";
	}
	function myFunction5() {
	  document.getElementById("myDropdown5").style.display="block";
	  document.getElementById("myDropdown1").style.display="none";
	  document.getElementById("myDropdown2").style.display="none";
	  document.getElementById("myDropdown3").style.display="none";
	  document.getElementById("myDropdown4").style.display="none";
	  document.getElementById("myDropdown6").style.display="none";
	  document.getElementById("myDropdown7").style.display="none";
	}
	function myFunction6() {
	  document.getElementById("myDropdown6").style.display="block";
	  document.getElementById("myDropdown1").style.display="none";
	  document.getElementById("myDropdown2").style.display="none";
	  document.getElementById("myDropdown3").style.display="none";
	  document.getElementById("myDropdown4").style.display="none";
	  document.getElementById("myDropdown5").style.display="none";
	  document.getElementById("myDropdown7").style.display="none";
	}
	function myFunction7() {
	  document.getElementById("myDropdown7").style.display="block";
	  document.getElementById("myDropdown1").style.display="none";
	  document.getElementById("myDropdown2").style.display="none";
	  document.getElementById("myDropdown3").style.display="none";
	  document.getElementById("myDropdown4").style.display="none";
	  document.getElementById("myDropdown5").style.display="none";
	  document.getElementById("myDropdown6").style.display="none";
	}