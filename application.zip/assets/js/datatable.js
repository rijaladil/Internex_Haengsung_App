// summary
$(document).ready(function() {
    $('.normal').DataTable({
        "scrollY"       : "580px",
        "scrollCollapse": true,
        "searching"     : false,
        "paging"        : true,
        "info"          : false,
        "pageLength"    : 25,
        "lengthChange"  : false,
        "ordering"      : false
    });
} );

// summary
$(document).ready(function() {
    $('#summary').DataTable({
    	"scrollY"		: "580px",
        "scrollCollapse": true,
        "searching"		: false,
        "paging"		: false,
        "info"			: false,
        "ordering"      : false
    });
} );

// product-status
$(document).ready(function() {
    $('#product-status').DataTable({
    	"scrollY"		: "620px",
        "scrollCollapse": true,
        "searching"		: false,
        "paging"		: false,
        "info"			: false,
        "ordering"      : false
    });
} );


// actual-production
// $(document).ready(function() {
//     $('#actual-production').DataTable({
//     	"scrollY"		: "230px",
//         "scrollCollapse": true,
//         "searching"		: false,
//         "paging"		: false,
//         "info"			: false
//     });

// } );


// setting-working1
$(document).ready(function() {
    $('#setting-working1').DataTable({
        "searching"     : false,
        "paging"        : false,
        "info"          : false,
        "ordering"      : false
    });
} );

// setting-working2
$(document).ready(function() {
    $('#setting-working2').DataTable({
        "searching"     : false,
        "paging"        : false,
        "info"          : false,
        "ordering"      : false
    });
} );


// setting-line-mc
$(document).ready(function() {
    $('#setting-line-mc').DataTable({
        "scrollY"       : "650px",
        "scrollCollapse": true,
        "searching"     : false,
        "paging"        : false,
        "info"          : false,
        "ordering"      : false
    });

} );


// setting-user
$(document).ready(function() {
    $('#setting-user').DataTable({
        "scrollY"       : "650px",
        "scrollCollapse": true,
        "searching"     : false,
        "paging"        : false,
        "info"          : false,
        "ordering"      : false
    });

} );


// setting-quality
$(document).ready(function() {
    $('#setting-quality1').DataTable({
        // "scrollY"       : "520px",
        // "scrollCollapse": true,
        "searching"     : false,
        "paging"        : false,
        "info"          : false,
        "ordering"      : false
    });

    $('#setting-quality2').DataTable({
        // "scrollY"       : "520px",
        // "scrollCollapse": true,
        "searching"     : false,
        "paging"        : false,
        "info"          : false,
        "ordering"      : false
    });

    $('#setting-quality3').DataTable({
        // "scrollY"       : "520px",
        // "scrollCollapse": true,
        "searching"     : false,
        "paging"        : false,
        "info"          : false,
        "ordering"      : false
    });

    $('#setting-quality4').DataTable({
        // "scrollY"       : "520px",
        // "scrollCollapse": true,
        "searching"     : false,
        "paging"        : false,
        "info"          : false,
        "ordering"      : false
    });

} );


// setting-loss-time
$(document).ready(function() {
    $('#setting-loss-time').DataTable({
        "scrollY"       : "550px",
        "scrollCollapse": true,
        "searching"     : false,
        "paging"        : false,
        "info"          : false,
        "ordering"      : false
    });

} );
