<!DOCTYPE html>
<html>
    <head>
        <script src="js/jquery-3.3.1.js" type="text/javascript"></script>
        <title>DAEBACK DISPLAY ANDON</title>
    </head>
    <body>
        <form method="post" action="modules/upload.php" enctype="multipart/form-data">
            <input type="file" name="ff"/>
            <input type="submit" value="OK"/>
        </form>
    </body>
</html>