/**
 * @license Highcharts JS v7.2.1 (2019-10-31)
 * @module highcharts/themes/sunset
 * @requires highcharts
 *
 * (c) 2009-2019 Highsoft AS
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../themes/sunset.js';
